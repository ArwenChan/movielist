Quick start
-----------

 Use it like this:

    python -m movielist

tips:

    It will generate a database file in the current directory. Before inquiries 

    about movies, you should get the year's movies data first.